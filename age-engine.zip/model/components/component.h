#ifndef COMPONENT_H
#define COMPONENT_H

struct Component {
    virtual ~Component() {}
};

#endif
