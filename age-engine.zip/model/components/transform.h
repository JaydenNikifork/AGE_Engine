#ifndef TRANSFORM_H
#define TRANSFORM_H

#include "component.h"

struct Transform: Component {
    int x, y, z;
};

#endif
