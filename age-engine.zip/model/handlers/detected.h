#ifndef DETECTED_H
#define DETECTED_H

struct Detected {
    virtual ~Detected() {}
};

#endif
