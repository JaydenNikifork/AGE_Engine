#ifndef INPUT_CONTROLLER
#define INPUT_CONTROLLER

class InputController {
public:
    virtual void scanForInputs() = 0;
};

#endif
