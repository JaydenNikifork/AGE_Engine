#ifndef ENUMS_H
#define ENUMS_H

using Input = char;

#endif
