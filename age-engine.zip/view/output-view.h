#ifndef OUTPUT_VIEW_H
#define OUTPUT_VIEW_H

#include <string>

class OutputView {

public:
    virtual void draw() = 0;
};

#endif
